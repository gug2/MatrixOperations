/*
 * LSM303DTR.c
 *
 *  Created on: 8 мая 2022 г.
 *      Author: andre
 */
#include "LSM303DTR.h"

static SPI_HandleTypeDef* hspi;
static GPIO_TypeDef* CS_GPIO_PORT;
static uint16_t CS_GPIO_PIN;

static uint8_t thermometerOnBit = 0;

static uint8_t address_data[2];
static uint8_t buf[6];

uint8_t LSM303DTR_ReadID() {
	uint8_t deviceID = 0x00;
	LSM303DTR_EnableCSB();
	HAL_SPI_TransmitReceive(hspi, (uint8_t*)0x0F, &deviceID, 1, 10);
	LSM303DTR_DisableCSB();

	return deviceID;
}

LSM303DTR_Status LSM303DTR_Init(SPI_HandleTypeDef* hspix, GPIO_TypeDef* gpioPort, uint16_t gpioPin) {
	hspi = hspix;
	CS_GPIO_PORT = gpioPort;
	CS_GPIO_PIN = gpioPin;

	if(LSM303DTR_ReadID() != 0x49) return LSM303DTR_DEVICE_ERROR;

	return LSM303DTR_DEVICE_OK;
}

void LSM303DTR_EnableThermometer() {
	// don't overwrite if thermometer is on
	if(thermometerOnBit == 0) {
		thermometerOnBit = 1;
		LSM303DTR_WriteTo(0x24, 0b00000000 | (thermometerOnBit << 7));
	}
}

void LSM303DTR_DisableThermometer() {
	// don't overwrite if thermometer is off
	if(thermometerOnBit != 0) {
		thermometerOnBit = 0;
		LSM303DTR_WriteTo(0x24, 0b00000000 | (thermometerOnBit << 7));
	}
}

void LSM303DTR_SetAccelerometerODR(LSM303DTR_Odr odr) {
	LSM303DTR_WriteTo(0x20, 0b00000111 | (odr << 4));
}

void LSM303DTR_SetCompassODR(LSM303DTR_Odr odr) {
	if(odr == LSM303DTR_ODR_POWER_DOWN || odr > LSM303DTR_ODR_100HZ) return;

	LSM303DTR_WriteTo(0x24, 0b00000000 | (thermometerOnBit << 7) | ((odr-1) << 2));
}

void LSM303DTR_SetAccelerometerFS(LSM303DTR_Fullscale fs) {
	LSM303DTR_WriteTo(0x21, 0b00000000 | (fs << 3));
}

void LSM303DTR_SetCompassFS(LSM303DTR_Compass_Fullscale fs) {
	LSM303DTR_WriteTo(0x25, 0b00000000 | (fs << 5));
}

void LSM303DTR_SetCompassMode(LSM303DTR_Compass_Mode mode) {
	LSM303DTR_WriteTo(0x26, 0b00000000 | mode);
}

void LSM303DTR_ReadData(LSM303DTR_Data_Typedef* data) {
	LSM303DTR_EnableCSB();
	HAL_SPI_Transmit(hspi, (uint8_t*)0x28, 1, 10);
	HAL_SPI_Receive(hspi, buf, 6, 10);
	LSM303DTR_DisableCSB();
	data->accel.x = (buf[1] << 8) | buf[0];
	data->accel.y = (buf[3] << 8) | buf[2];
	data->accel.z = (buf[5] << 8) | buf[4];

	LSM303DTR_EnableCSB();
	HAL_SPI_Transmit(hspi, (uint8_t*)0x08, 1, 10);
	HAL_SPI_Receive(hspi, buf, 6, 10);
	LSM303DTR_DisableCSB();
	data->compass.x = (buf[1] << 8) | buf[0];
	data->compass.y = (buf[3] << 8) | buf[2];
	data->compass.z = (buf[5] << 8) | buf[4];

	if(thermometerOnBit > 0) {
		LSM303DTR_EnableCSB();
		HAL_SPI_Transmit(hspi, (uint8_t*)0x05, 1, 10);
		HAL_SPI_Receive(hspi, buf, 2, 10);
		LSM303DTR_DisableCSB();
		data->temperature = (buf[1] << 8) | buf[0];
	}
}

void LSM303DTR_WriteTo(uint8_t address, uint8_t data) {
	address_data[0] = address;
	address_data[1] = data;
	LSM303DTR_EnableCSB();
	HAL_SPI_Transmit(hspi, address_data, 2, 10);
	LSM303DTR_DisableCSB();
}

void LSM303DTR_EnableCSB() {
	HAL_GPIO_WritePin(CS_GPIO_PORT, CS_GPIO_PIN, GPIO_PIN_RESET);
}

void LSM303DTR_DisableCSB() {
	HAL_GPIO_WritePin(CS_GPIO_PORT, CS_GPIO_PIN, GPIO_PIN_SET);
}
