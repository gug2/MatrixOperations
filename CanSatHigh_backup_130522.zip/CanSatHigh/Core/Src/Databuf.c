/*
 * Databuf.c
 *
 *  Created on: May 13, 2022
 *      Author: andre
 */
#include "Databuf.h"

static uint8_t databuf[128] = {0};
static uint16_t datasize = 0;

uint8_t* Buf_getDatabuf() {
	return databuf;
}

uint16_t Buf_getDatasize() {
	return datasize;
}

/* Clear the data buffer */
void Buf_clear() {
	for(uint16_t i = 0; i < datasize; i++) databuf[i] = 0;

	datasize = 0;
}

/* Push two bytes to data buffer (LSB first) */
void Buf_push16(int16_t twoBytes) {
	// tb & 0x00FF   FF << 0
	// tb & 0xFF00   FF << 8
	uint8_t offset = 0;
	for(uint8_t i = 0; i < 2; i++) {
		offset = 8*i;
		databuf[datasize] = (uint8_t)((twoBytes & (0xFF << offset)) >> offset);
		datasize++;
	}
}

void Buf_push32(uint32_t bytes) {
	uint8_t offset = 0;
	for(uint8_t i = 0; i < 4; i++) {
		offset = 8*i;
		databuf[datasize] = (uint8_t)((bytes & (0xFF << offset)) >> offset);
		datasize++;
	}
}

int16_t Buf_pop16() {
	int16_t res = 0;
	for(uint8_t i = 1; i >= 0; i++) {
		// add current data to result integer
		res |= databuf[datasize] << 8*i;

		// clear the data
		databuf[datasize] = 0;
		// decrease counter
		datasize--;
	}

	return res;
}

uint32_t Buf_pop32() {
	uint32_t res = 0;
	for(uint8_t i = 3; i >= 0; i++) {
		// add current data to result integer
		res |= databuf[datasize] << 8*i;

		// clear the data
		databuf[datasize] = 0;
		// decrease counter
		datasize--;
	}

	return res;
}

float int16_tToFloat(int16_t twoBytes, uint8_t multiplier) {
	return twoBytes / 32768.0F * multiplier;
}
