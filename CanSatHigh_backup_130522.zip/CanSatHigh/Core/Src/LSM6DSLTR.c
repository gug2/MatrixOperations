/*
 * LSM6DSLTR.c
 *
 *  Created on: May 14, 2022
 *      Author: andre
 */
#include "LSM6DSLTR.h"

static SPI_HandleTypeDef* hspi;
static GPIO_TypeDef* CS_GPIO_PORT;
static uint16_t CS_GPIO_PIN;

static uint8_t address_data[2];

uint8_t LSM6DSLTR_ReadID() {
	uint8_t deviceID = 0x00;
	LSM6DSLTR_EnableCSB();
	HAL_SPI_TransmitReceive(hspi, (uint8_t*)0x0F, &deviceID, 1, 10);
	LSM6DSLTR_DisableCSB();

	return deviceID;
}

LSM6DSLTR_Status LSM6DSLTR_Init(SPI_HandleTypeDef* hspix, GPIO_TypeDef* gpioPort, uint16_t gpioPin) {
	hspi = hspix;
	CS_GPIO_PORT = gpioPort;
	CS_GPIO_PIN = gpioPin;

	// reset the device
	LSM6DSLTR_SoftReset();

	if(LSM6DSLTR_ReadID() != 0x6A) return LSM6DSLTR_DEVICE_ERROR;

	return LSM6DSLTR_DEVICE_OK;
}

void LSM6DSLTR_SetAccelerometerODR_FS(LSM6DSLTR_ODR odr, LSM6DSLTR_Accelerometer_Fullscale fs) {
	LSM6DSLTR_WriteTo(0x10, 0b00000000 | (odr << 4) | (fs << 2));
}

void LSM6DSLTR_SetGyroscopeODR_FS(LSM6DSLTR_ODR odr, LSM6DSLTR_Gyroscope_Fullscale fs, LSM6DSLTR_Settings flag) {
	if(odr > LSM6DSLTR_ODR_6660HZ) return;

	LSM6DSLTR_WriteTo(0x11, 0b00000000 | (odr << 4) | (fs << 2) | (flag << 1));
}

/* Soft device reset */
void LSM6DSLTR_SoftReset() {
	uint8_t data = 0;
	HAL_SPI_Transmit(hspi, (uint8_t*)0x12, 1, 10);
	HAL_SPI_Receive(hspi, &data, 1, 10);

	LSM6DSLTR_WriteTo(0x12, data | 1);
}

void LSM6DSLTR_WriteTo(uint8_t address, uint8_t data) {
	address_data[0] = address;
	address_data[1] = data;
	LSM6DSLTR_EnableCSB();
	HAL_SPI_Transmit(hspi, address_data, 2, 10);
	LSM6DSLTR_DisableCSB();
}

void LSM6DSLTR_EnableCSB() {
	HAL_GPIO_WritePin(CS_GPIO_PORT, CS_GPIO_PIN, GPIO_PIN_RESET);
}

void LSM6DSLTR_DisableCSB() {
	HAL_GPIO_WritePin(CS_GPIO_PORT, CS_GPIO_PIN, GPIO_PIN_SET);
}
